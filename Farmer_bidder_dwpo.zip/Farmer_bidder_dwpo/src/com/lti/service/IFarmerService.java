package com.lti.service;

import org.springframework.stereotype.Service;

import com.lti.model.Farmer;

@Service
public interface IFarmerService {
public void addFarmer(Farmer farmer);

}
